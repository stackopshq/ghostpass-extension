/* tslint:disable */
/* eslint-disable */

/**
 * Compte déverrouillé : détient les clés en mémoire WASM (jamais exposées en clair au JS).
 */
export class Account {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Crée une organisation : génère une Org Key et la scelle (authentifiée) pour soi-même.
     */
    create_org(): OrgCreation;
    /**
     * Crée un kit de récupération. Renvoie un JSON
     * `{ recovery_key, recovery_auth_hash, encrypted_user_key_recovery }`.
     * `recovery_key` est à AFFICHER à l'utilisateur ; les deux autres champs partent au serveur.
     */
    create_recovery(): string;
    /**
     * Déchiffre un JSON `EncryptedItem` avec l'USK. Renvoie le JSON `VaultItem`.
     */
    decrypt_item(encrypted_item_json: string): string;
    /**
     * Paramètres KDF par défaut (JSON), à stocker avec le compte côté serveur.
     */
    static default_kdf_params(): string;
    /**
     * Chiffre un item de coffre (JSON `VaultItem`) avec l'USK. Renvoie un JSON `EncryptedItem`.
     */
    encrypt_item(item_json: string): string;
    /**
     * Hash d'authentification (base64) à envoyer au serveur lors d'une connexion.
     */
    static master_password_hash(password: string, email: string, kdf_params_json: string): string;
    /**
     * (Contact) Ouvre un accès d'urgence reçu d'un grantor : récupère son USK en mémoire WASM,
     * en vérifiant que le blob provient bien de la clé publique du grantor.
     */
    open_emergency(grantor_public_key: string, sealed: string): EmergencyVault;
    /**
     * Ouvre une Org Key reçue d'un admin, en vérifiant qu'elle provient de sa clé publique.
     */
    open_org(admin_public_key: string, sealed: string): Org;
    /**
     * Récupère un compte via sa clé de récupération et réinitialise le mot de passe maître.
     */
    static recover(recovery_key: string, email: string, new_password: string, kdf_params_json: string, encrypted_user_key_recovery: string, encrypted_private_key: string): RecoveryResult;
    /**
     * Crée un compte : génère les clés et le blob chiffré d'inscription.
     */
    static register(password: string, email: string): Registration;
    /**
     * Scelle l'Org Key pour un membre (en tant qu'admin émetteur). Renvoie le blob base64.
     */
    seal_org_key_for_member(org: Org, member_public_key: string): string;
    /**
     * Scelle l'USK du compte pour un contact de confiance (accès d'urgence), authentifié.
     * Le blob (base64) est stocké côté serveur et n'est ouvrable qu'avec la clé privée du contact.
     */
    seal_user_key_for(contact_public_key: string): string;
    /**
     * Déverrouille un compte existant à partir des blobs chiffrés (format `EncString`).
     */
    static unlock(password: string, email: string, kdf_params_json: string, encrypted_user_key: string, encrypted_private_key: string): Account;
    /**
     * Déverrouille un compte SANS mot de passe à partir du secret PRF (base64) de la passkey,
     * de l'USK enveloppée par PRF et de la clé privée chiffrée.
     */
    static unlock_with_passkey(prf_secret_b64: string, prf_wrapped_user_key: string, encrypted_private_key: string): Account;
    /**
     * Enveloppe l'USK avec le secret PRF (base64) d'une passkey, pour le déverrouillage sans
     * mot de passe. Renvoie l'`EncString` à stocker côté serveur.
     */
    wrap_user_key_for_passkey(prf_secret_b64: string): string;
    /**
     * Clé publique de partage (base64), à publier côté serveur pour recevoir des secrets partagés.
     */
    readonly public_key: string;
}

/**
 * Accès d'urgence ouvert côté contact : détient l'USK du grantor (jamais exposée au JS).
 */
export class EmergencyVault {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Lecture : déchiffre un item du coffre du grantor avec son USK récupéré.
     */
    decrypt_item(encrypted_item_json: string): string;
    /**
     * Takeover : prépare la réinitialisation du mot de passe maître du grantor à partir de son
     * USK récupéré. Renvoie un JSON `{ master_password_hash, encrypted_user_key }`.
     */
    takeover(grantor_email: string, kdf_params_json: string, new_password: string): string;
}

/**
 * Contexte d'une organisation : détient l'Org Key en mémoire WASM (jamais exposée au JS).
 */
export class Org {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Déchiffre un JSON `EncryptedItem` sous l'Org Key. Renvoie le JSON `VaultItem`.
     */
    decrypt_item(encrypted_item_json: string): string;
    /**
     * Chiffre un item (JSON `VaultItem`) sous l'Org Key. Renvoie un JSON `EncryptedItem`.
     */
    encrypt_item(item_json: string): string;
    /**
     * Ré-enveloppe un item d'une ancienne Org Key vers celle-ci (rotation / révocation),
     * sans déchiffrer le contenu.
     */
    rewrap_item(old_org: Org, encrypted_item_json: string): string;
}

/**
 * Résultat de la création d'une org : le contexte `Org` + l'Org Key scellée pour le créateur
 * (à stocker côté serveur comme entrée du membre-admin).
 */
export class OrgCreation {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Récupère le contexte `Org` (les clés). Ne peut être appelé qu'une fois.
     */
    org(): Org;
    /**
     * Org Key scellée pour le créateur (base64), à transmettre au serveur.
     */
    readonly sealed_for_self: string;
}

/**
 * Résultat d'une récupération : le `reset` (JSON à envoyer au serveur) + l'`Account` rouvert.
 */
export class RecoveryResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    account(): Account;
    /**
     * JSON du `ResetBlob` (nouveau hash d'auth, preuve de récupération, nouvelle USK enveloppée).
     */
    readonly reset: string;
}

/**
 * Résultat d'une inscription : le `blob` (JSON à envoyer au serveur) et l'`Account` (les clés).
 */
export class Registration {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Récupère l'`Account` (les clés en mémoire). Ne peut être appelé qu'une fois.
     */
    account(): Account;
    /**
     * JSON du `RegistrationBlob` à transmettre au serveur (qui ne peut rien en déchiffrer).
     */
    readonly blob: string;
}

/**
 * Ouvre un secret partagé.
 */
export function open_send(key: string, nonce: string, ciphertext: string): string;

/**
 * Scelle un secret sous une clé neuve. Renvoie un JSON
 * `{ ciphertext, nonce, key }` — la clé voyage dans le fragment du lien, que les
 * navigateurs n'envoient jamais au serveur.
 *
 * Le chiffrement se fait ici, dans le cœur, et non plus en AES-GCM via WebCrypto : c'était
 * le seul endroit du produit où de la crypto vivait hors du cœur, et c'est ce qui
 * empêchait l'application iOS d'ouvrir un partage créé depuis le navigateur.
 */
export function seal_send(plaintext: string): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_account_free: (a: number, b: number) => void;
    readonly __wbg_registration_free: (a: number, b: number) => void;
    readonly registration_blob: (a: number) => [number, number];
    readonly registration_account: (a: number) => [number, number, number];
    readonly __wbg_recoveryresult_free: (a: number, b: number) => void;
    readonly recoveryresult_reset: (a: number) => [number, number];
    readonly recoveryresult_account: (a: number) => [number, number, number];
    readonly account_default_kdf_params: () => [number, number, number, number];
    readonly account_register: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly account_unlock: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => [number, number, number];
    readonly account_master_password_hash: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly account_create_recovery: (a: number) => [number, number, number, number];
    readonly account_recover: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number) => [number, number, number];
    readonly account_public_key: (a: number) => [number, number];
    readonly account_encrypt_item: (a: number, b: number, c: number) => [number, number, number, number];
    readonly account_decrypt_item: (a: number, b: number, c: number) => [number, number, number, number];
    readonly account_wrap_user_key_for_passkey: (a: number, b: number, c: number) => [number, number, number, number];
    readonly account_unlock_with_passkey: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly seal_send: (a: number, b: number) => [number, number, number, number];
    readonly open_send: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly __wbg_org_free: (a: number, b: number) => void;
    readonly org_encrypt_item: (a: number, b: number, c: number) => [number, number, number, number];
    readonly org_decrypt_item: (a: number, b: number, c: number) => [number, number, number, number];
    readonly org_rewrap_item: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly __wbg_orgcreation_free: (a: number, b: number) => void;
    readonly orgcreation_sealed_for_self: (a: number) => [number, number];
    readonly orgcreation_org: (a: number) => [number, number, number];
    readonly account_create_org: (a: number) => [number, number, number];
    readonly account_open_org: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly account_seal_org_key_for_member: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly account_seal_user_key_for: (a: number, b: number, c: number) => [number, number, number, number];
    readonly account_open_emergency: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly __wbg_emergencyvault_free: (a: number, b: number) => void;
    readonly emergencyvault_decrypt_item: (a: number, b: number, c: number) => [number, number, number, number];
    readonly emergencyvault_takeover: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number, number];
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
